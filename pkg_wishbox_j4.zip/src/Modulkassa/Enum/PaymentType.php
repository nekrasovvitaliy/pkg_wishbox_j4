<?php
/**
 * @copyright 2023 Nekrasov Vitaliy
 * @license GNU General Public License version 2 or later
 */
namespace Wishbox\Modulkassa\Enum;
enum PaymentType
{
	case CASH;
	case CARD;
}
